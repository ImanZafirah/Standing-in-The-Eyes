<?php
session_start();
//check if session exists
if(isset($_SESSION["UserID"])) {
?>
<html>
<head>
        <title> SPECIAL SONGS COLLECTION </title>

        <style>

    body{
        background-image: url("Lagu3.webp");
        color: black;
    }
    .container{
        padding: 100px;
        font-family: arial, sans-serif;
        text-align: center;
    }
    button{
        border-radius: 20px;
        font-size: 20px;
        width: 400px;
        height: 100px;
    }
    
    </style>
</head>
<body>
<div class ="container">
<h2> WELCOME, Hi <?php echo $_SESSION["UserID"]; ?> </h2>
<p> Choose your menu : </p> 

<?php
if  ($_SESSION["UserType"] == "admin") {
?>

<button onclick="window.location.href = 'viewSongs_admin.php'">View Songs List</button><br><br>
<button onclick="window.location.href = 'viewUsers_admin.php'">View User Status</button><br><br>
<button onclick="window.location.href = 'songs_statusView.php'">Change Songs Status</button><br><br>
<button onclick="window.location.href = 'Songs_adminManageView.php'">Change User Status</button><br><br>

<?php
}
else {
?>
<button onclick="window.location.href = 'newsongs_form.php'">Register New Songs</button><br><br>
<button onclick="window.location.href = 'songs_editView.php'">Edit Songs Details</button><br><br>
<button onclick="window.location.href = 'songs_deleteView.php'">Delete Songs Record</button><br><br>
<button onclick="window.location.href = 'viewSongs.php'">View Song List</button><br><br>
<?php
}
?>
<button onclick="window.location.href = 'logout.php'">Logout</button><br><br>

</div>
</body>
</html>
<?php
}
else
{
    echo "No session exists or session has expired. Please log in again. <br> ";
    echo "<a href = 'login.html'> Login </a>";
}
?>
<?php
session_start();
//check if session exists
if(isset($_SESSION["UserID"])) {
?>
<!DOCTYPE html>
<html>
<head>
<title> Special Songs Collection </title>

<style>
  body{
    background-color: bisque;
  }
  </style>
</head>

<body>
    <h2> Songs List </h2>

<?php
$Song_ID = $_POST["Song_ID"];

$host = "localhost";
$user = "root";
$password = "";
$db = "songsdb";
$conn = new mysqli($host,$user,$password,$db);

if ($conn->connect_error) {
    die ("Connection Failed..." . $conn->connect_error);
  }
  else
  {
    $deleteQuery = "DELETE FROM SONGS WHERE Song_ID = '".$Song_ID."' ";

    if ($conn->query($deleteQuery) === TRUE) {
        echo "<p style='color:blue;'> Record has been deleted from database !</p>";
        echo "Click <a href='viewSongs.php'> here </a> to VIEW SONGS LIST ";
        } else {
        echo "<p style='color:red;'>Query problems! : " .$conn->error . "</p>";
        }
        $conn->close();
    }
    ?>
    </body>
    </html>

<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
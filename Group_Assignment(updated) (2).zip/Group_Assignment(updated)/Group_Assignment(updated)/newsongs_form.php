<?php
session_start();
//check if session exists
if(isset($_SESSION["UserID"])) {
?>
<!DOCTYPE html>
<html>

<head>
  <meta charset="UTF-8">
  <title> SPECIAL SONGS COLLECTION </title>
  <style>
    body {
      font-family: Arial, sans-serif;
      color: #333;
      background-color: powderblue;
    }
    h1 {
      font-size: 24px;
      margin-bottom: 10px;
    }
    h2 {
      font-size: 18px;
      margin-bottom: 5px;
    }
    .required {
      color: red;
      font-style: italic;
    }
    </style>
</head>
<body>


  <h1>Songs Registration Form</h1>
  <h2>Enter Songs Details:</h2>
  <p class="required">*ALL fields are required</p>

  <form name="Songs Registration Details" action="songs_register.php" method="post">

    <label for="Song Title"><b>Name of the song :</b></label>
    <input type="text" name="Song_Title" maxlength="30" required><br><br>

    <label for="Song Artist"><b>Song Artist/Band Name :</b></label>
    <input type="text" name="Song_Artist" maxlength="30" required><br><br>

    <label for="Song URL"><b>Audio/Video of the song (URL) :</b></label>
    <input type="url" name="Song_URL" maxlength="30" required><br><br>

    <label for="Song Genre"><b>Song Genre :</b></label>
    <select name="Song_Genre" required>
      <option value="R&B">R&B</option>
      <option value="Rock">Rock</option>
      <option value="Hip-Hop">Hip-Hop</option>
      <option value="Jazz">Jazz</option>
      <option value="Pop">Pop</option>
    </select><br><br>

    <label for="Song Language"><b>Song Language :</b></label>
    <input type="text" name="Song_Language" maxlength="10" required><br><br>

    <label for="Released Date"><b>Song Release Date :</b></label>
    <input type="date" name="Release_Date"  required><br><br>

    <input type="submit" value="Display Song Details">
    <button type="button" onclick="cancelForm()">Cancel</button>
  </form>


</body>
</html>

<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
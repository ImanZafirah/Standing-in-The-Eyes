<?php
session_start();
//check if session exists
if(isset($_SESSION["UserID"])) {
?>
<!DOCTYPE html>
<html>
<head>
<title> Special Songs Collection </title>

<style>
  body{
    background-color: lightgreen;
  }
  </style>
</head>

<body>
    <h2> Songs List </h2>

<p style="color:purple;font-weight:bold;"> Update Songs Details </p>

<?php
$songid = $_POST["Song_ID"];

$host = "localhost";
$user = "root";
$password = "";
$db = "songsdb";
$conn = new mysqli($host,$user,$password,$db);

if ($conn->connect_error) {
    die ("Connection Failed..." . $conn->connect_error);
  }
  else
  {
    $queryGet = "SELECT * FROM SONGS WHERE Song_ID='".$songid."'";
    $resultQ = $conn->query($queryGet);

    if ($resultQ->num_rows > 0) {

?>

<form action="songs_editSave.php" name="UpdateForm" method="POST">


<?php
while($baris = $resultQ->fetch_assoc()) {
?>

Song ID: <b><?php echo $baris ['Song_ID']; ?></b> 
<br><br>
Song Title: <input type="text" name="Song_Title" value="<?php echo $baris['Song_Title'];?>" maxlenght="30" size="35" required>
<br><br>
Song Artist: <input type="text" name="Song_Artist" value="<?php echo $baris['Song_Artist'];?>" maxlenght="30" size="35" required>
<br><br>
Song URL: <input type="url" name="Song_URL" value="<?php echo $baris['Song_URL'];?>" maxlenght="30" size="35" required>
<br><br>
Song Genre: 
<?php $Song_Genre = $baris['Song_Genre'];?>
<select name="Song_Genre" required>
    <option value=""> - Please Choose - </option>
    <option value="R&B" <?php if($Song_Genre == "R&B") echo "selected"; ?>> R&B</option>
    <option value="Rock" <?php if($Song_Genre == "Rock") echo "selected"; ?>> Rock</option>
    <option value="Hip-Hop" <?php if($Song_Genre == "Hip-Hop") echo "selected"; ?>> Hip-Hop</option>
    <option value="Jazz" <?php if($Song_Genre == "Jazz") echo "selected"; ?>> Jazz</option>
    <option value="Pop" <?php if($Song_Genre == "Pop") echo "selected"; ?>> Pop</option>
</select>
<br> <br>
Song Language: <input type="text" name="Song_Language" value="<?php echo $baris['Song_Language'];?>" maxlenght="10" size="30" required>
<br><br>
Song Release Date: <input type="date" name="Release_Date" value="<?php echo $baris['Release_Date'];?>" required>
<br><br>


<?php

?>
<br><br>
<input type="hidden" name="Song_ID" value="<?php echo $baris['Song_ID']; ?>">
<input type="submit" value="Update New Details">
</form>
<?php
}
    }
}
$conn->close();
?>
</body>
</html>

<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
<?php
session_start();
//check if session exists
if(isset($_SESSION["UserID"])) {
?>
<!DOCTYPE html>
<html>
<head>
<title> User Status Update </title>

<style>
  body{
    background-color: honeydew;
  }
  </style>
</head>

<body>
    <h3> SONGS UPDATE SAVE </h3>

<?php

$UserID = $_POST['UserID'];
$UserStatus = $_POST['UserStatus'];



$host = "localhost";
$user = "root";
$pass = "";
$db = "songsdb";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed..." . $conn->connect_error);
} else {

    $queryUpdate = "UPDATE USERS SET UserStatus = '$UserStatus'  WHERE UserID = '$UserID' ";

    if ($conn->query($queryUpdate) === TRUE) {
        echo "<p style='color:blue;'>Record has been updated into database.</p>";
        echo "<br><br>";
        echo "Click <a href='viewUsers_admin.php'> here </a> to view user status list ";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

$conn->close();
?>

</body>
</html>
<?php

}else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
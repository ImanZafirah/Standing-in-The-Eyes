<?php
session_start();
//check if session exists
if(isset($_SESSION["UserID"])) {
?>
<!DOCTYPE html>
<html>
<head>
<title> Special Songs Collection </title>

<style>
  body{
    background-color: pink;
  }
  </style>
</head>

<body>
    <h2> Songs List </h2>

<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "songsdb";
$conn = new mysqli($host,$user,$password,$db);

if ($conn->connect_error) {
    die ("Connection Failed..." . $conn->connect_error);
  }
  else
  {
    $queryView = "SELECT * FROM SONGS";
    $resultQ = $conn->query($queryView);
?>

<form action="songs_editStatus.php" method="POST" onsubmit="return confirm('Are you sure to edit this record?')">
<table border="2">
  <tr>
    <th> Select </th>
    <th> Song ID </th>
    <th> Song Title</th>
    <th> Song Artist</th>
    <th> Song URL </th>
    <th> Song Genre </th>
    <th> Song Language </th>
    <th> Release Date </th>
    <th> Song Status</th>
  </tr>

<?php
if ($resultQ->num_rows > 0) {
    while ($row = $resultQ->fetch_assoc()){
?>
<tr>
    <td> <input type="radio" name="Song_ID" value="<?php echo $row["Song_ID"]; ?>" required> </td>
    <td> <?php echo $row["Song_ID"]; ?> </td>
    <td> <?php echo $row["Song_Title"]; ?> </td>
    <td> <?php echo $row["Song_Artist"]; ?> </td>
    <td> <a href=<?php echo $row["Song_URL"]; ?>>Click</a> </td>
    <td> <?php echo $row["Song_Genre"]; ?> </td>
    <td> <?php echo $row["Song_Language"]; ?> </td>
    <td> <?php echo $row["Release_Date"]; ?> </td>
    <td> <?php echo $row["Song_Status"]; ?> </td>
</tr>

<?php
    }
    } else {
        echo "<tr><td colspan='9'> NO data selected </td></tr>";
    }
}
?>
</table>

<?php
$conn->close();
?>

<br><br>
<input type="submit" value="View record to Edit">
</form>
</body>
</html>

<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
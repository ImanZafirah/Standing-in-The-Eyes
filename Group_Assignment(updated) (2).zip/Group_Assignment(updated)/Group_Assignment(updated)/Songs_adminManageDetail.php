<?php
session_start();
//check if session exists
if(isset($_SESSION["UserID"])) {
?>
<!DOCTYPE html>
<html>
<head>
<title> Special Songs Collection </title>

<style>
  body{
    background-color: honeydew;
  }
  </style>
</head>

<body>
    <h2> Songs List </h2>

<p style="color:purple;font-weight:bold;"> Update Songs Details </p>

<?php
$UserID = $_POST["UserID"];

$host = "localhost";
$user = "root";
$password = "";
$db = "songsdb";
$conn = new mysqli($host,$user,$password,$db);

if ($conn->connect_error) {
    die ("Connection Failed..." . $conn->connect_error);
  }
  else
  {
    $queryGet = "SELECT * FROM USERS WHERE UserID='".$UserID."'";
    $resultQ = $conn->query($queryGet);

?>

<form action="Songs_adminManageSave.php" method="POST" >
<table border="2">
  <tr>
    
    <th> User ID </th>
    <th> User Title</th>
    <th> User Status</th>
  </tr>

<?php
if ($resultQ->num_rows > 0) {
    while ($row = $resultQ->fetch_assoc()){
?>
<tr>
    
    <td> <?php echo $row["UserID"]; ?> </td>
    <td> <?php echo $row["UserType"]; ?> </td>
 
    <td>
    <select name="UserStatus" id="UserStatus" style="width: 100px;">
    <option value="Active"<?php if($row["UserStatus"] == "Active") echo "selected"; ?>> Active </option>
    <option value="Blocked" <?php if($row["UserStatus"] == "Blocked") echo "selected"; ?>> Block </option>
    </select>
</tr>

<input type="hidden" name="UserID" value="<?php echo $row['UserID']; ?>">

<?php
    }
    } else {
        echo "<tr><td colspan='3'> NO data selected </td></tr>";
    }

?>
</table>

<br><br>

<input type="submit" value="Update User Status">

</form>

<?php
}
    
$conn->close();
?>
</body>
</html>

<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
<?php
session_start();
//check if session exists
if(isset($_SESSION["UserID"])) {
?>
<!DOCTYPE html>
<html>
<head>
<title> Special Songs Collection </title>

<style>
  body{
    background-color: lightgreen;
  }
  </style>
</head>

<body>
    <h3> SONGS UPDATE SAVE </h3>

<?php

$Song_ID = $_POST['Song_ID'];
$Song_Title = $_POST['Song_Title'];
$Song_Artist = $_POST['Song_Artist'];
$Song_URL = $_POST['Song_URL'];
$Song_Genre = $_POST['Song_Genre'];
$Song_Language = $_POST['Song_Language'];
$Release_Date = $_POST['Release_Date'];


$host = "localhost";
$user = "root";
$pass = "";
$db = "songsdb";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed..." . $conn->connect_error);
} else {

   

    $queryUpdate = "UPDATE SONGS SET Song_ID = '$Song_ID', Song_Title = '$Song_Title', Song_Artist = '$Song_Artist', Song_URL = '$Song_URL', Song_Genre = '$Song_Genre', Song_Language = '$Song_Language', Release_Date = '$Release_Date'  WHERE Song_ID = '$Song_ID' ";

    if ($conn->query($queryUpdate) === TRUE) {
        echo "Record has been updated into database.";
        echo "<br><br>";
        echo "Click <a href='viewSongs.php'> here </a> to view song list ";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

$conn->close();
?>

</body>
</html>
<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
<?php
session_start();
//check if session exists
if(isset($_SESSION["UserID"])) {
?>
<!DOCTYPE html>
<html>
<head>
<title> Special Songs Collection </title>

<style>
  body{
    background-color: pink;
  }
  </style>
</head>

<body>
    <h3> SONGS UPDATE SAVE </h3>

<?php

$Song_ID = $_POST['Song_ID'];
$Song_Status = $_POST['status'];


$host = "localhost";
$user = "root";
$pass = "";
$db = "songsdb";

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Connection failed..." . $conn->connect_error);
} else {

   

    $queryUpdate = "UPDATE SONGS SET Song_Status = '".$Song_Status."'  WHERE Song_ID = '".$Song_ID."' ";

    if ($conn->query($queryUpdate) === TRUE) {
        echo "Record has been updated into database.";
        echo "<br><br>";
        echo "Click <a href='viewSongs_admin.php'> here </a> to view song list ";
    } else {
        echo "Error updating record: " . $conn->error;
    }
}

$conn->close();
?>

</body>
</html>
<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
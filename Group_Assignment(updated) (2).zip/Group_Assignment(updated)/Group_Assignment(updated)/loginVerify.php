<?php

$userID = $_POST['userID'];
$userPwd = $_POST['userPwd'];

$host = "localhost";
$username = "root";
$password = "";
$dbname = "songsdb";
$link = new mysqli($host, $username, $password, $dbname);
if ($link->connect_error)
{ 
 die("Connection failed: " . $link->connect_error); 
}
else
{
 $queryCheck = "SELECT * FROM USERS WHERE UserID = '".$userID."' ";
 $resultCheck = $link->query($queryCheck);
 if ($resultCheck->num_rows == 0)
 {
 echo "<p style='color:red;'>User ID does not exists </p>";
 echo "<br>Click <a href='login.html'> here </a> to log-in again";
 }
 else
 {
    $row = $resultCheck->fetch_assoc();
    if( $row["UserPass"] == $userPwd )
 {
   if ($row["UserStatus"] == 'blocked') {
   echo "<p style='color:red;'><br>Your account is blocked. Please contact support. </p>";           
   echo "<br>Click <a href='login.html'> here</a> to return to the login page";
} 
else {
   // calling the session_start() is compulsory
   session_start();

   // assign userID & userType values to session variables
   $_SESSION["UserID"] = $userID;
   $_SESSION["UserType"] = $row["UserType"];

   // redirect to file menu.php upon successful login
   header("Location:menu.php");
   }
} else { // if the password does not match
      echo "<p style='color:red;'><br>Wrong password!!! </p>";
      echo "Click <a href='login.html'> here</a> to log in again";
      }
   }
}

$link->close();
?>
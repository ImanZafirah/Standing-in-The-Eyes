<?php
session_start();
//check if session exists
if(isset($_SESSION["UserID"])) {
?>
<!DOCTYPE html>
<html>
<head>
<title> Special Songs Collection </title>
</head>

<body>
    <h2> Songs List </h2>

<?php
$song_name = $_POST["SearchSong"];
$host = "localhost";
$user = "root";
$password = "";
$db = "songsdb";
$conn = new mysqli($host,$user,$password,$db);

if ($conn->connect_error) {
    die ("Connection Failed..." . $conn->connect_error);
  }
  else
  {
    $queryView = "SELECT * FROM SONGS WHERE Song_Title LIKE '%$song_name%'";
    $resultQ = $conn->query($queryView);
?>
<form action="search_result.php" method="POST">
  Search song:  <input type="text" placeholder="Search Song" name="SearchSong">
  <input type="submit" value="Search">
</form>
<table border="2">
  <tr>
    <th> Songs ID</th>
    <th> Songs Title</th>
    <th> Song Artist/Band Name </th>
    <th> Song URL </th>
    <th> Song Genre </th>
    <th> Song Language </th>
    <th> Release Date </th>
    <th> Owner ID </th>
    <th> Status </th>
  </tr>

<?php
if ($resultQ->num_rows > 0) {
    while ($row = $resultQ->fetch_assoc()){
?>
<tr>
    <td> <?php echo $row["Song_ID"]; ?> </td>
    <td> <?php echo $row["Song_Title"]; ?> </td>
    <td> <?php echo $row["Song_Artist"]; ?> </td>
    <td> <a href=<?php echo $row["Song_URL"]; ?>>Click</a> </td>
    <td> <?php echo $row["Song_Genre"]; ?> </td>
    <td> <?php echo $row["Song_Language"]; ?> </td>
    <td> <?php echo $row["Release_Date"]; ?> </td>
    <td> <?php echo $row["Owner_ID"]; ?> </td>
    <td> <?php echo $row["Song_Status"]; ?> </td>
</tr>

<?php
    }
    } else {
        echo "<tr><td colspan='8'> NO data selected </td></tr>";
    }
}
?>
</table>

<?php
$conn->close();
?>

<br>
<p> Click <a href="menu.php">here</a> back to MENU page. </p>


</body>
</html>
<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
<style>
  body {
    background-image: url('Lagu.jpg');
    padding-top: 50px;
  padding-right: 30px;
  padding-bottom: 50px;
  padding-left: 80px;
  font-size: 20px;
  
  }

  .container{
    padding :50px;
  }
</style>
<div class=container>
<?php
session_start();
if (isset($_SESSION["UserID"]))
{
session_unset();
session_destroy();
echo "<center><br><p style='color:red;bottom: 50%;'>You have successfully logged out.</p></center>";
echo "<center><br>Click <a href='login.html'> here </a> to LOGIN again.</center>";
} else {
echo "<center> <p style='color:red;' >No session exists or session is expired. Please log in again</p> </center>";
echo "<center> <br>Click <a href='login.html'> here </a> to LOGIN again. </center>";
}
?>
</div>
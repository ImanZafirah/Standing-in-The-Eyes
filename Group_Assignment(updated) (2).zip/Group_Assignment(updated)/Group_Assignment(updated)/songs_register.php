<?php
session_start();
//check if session exists
if(isset($_SESSION["UserID"])) {
?>

<!DOCTYPE html>
<html>
<head>
  <title> Special Songs Collection </title>

  <style>
  body{
    background-color: powderblue;
  }
  </style>
</head>

<body>

<?php

$Song_Title = $_POST['Song_Title'];
$Song_Artist = $_POST['Song_Artist'];
$Song_URL = $_POST['Song_URL'];
$Song_Genre = $_POST['Song_Genre'];
$Song_Language = $_POST['Song_Language'];
$Release_Date = $_POST['Release_Date'];

?>

  <h1>Songs Registration Details</h1><br>
  

  <table border="1">

  <tr>
    <td> Song Title: </td>
    <td> <b> <?php echo $Song_Title; ?></b></td>

  <tr>
    <td> Song Artist/Band: </td>
    <td><b> <?php echo $Song_Artist; ?></b></td>

  <tr>
    <td> Song URL: </td>
    <td><b> <?php echo $Song_URL; ?></b></td>

  <tr>
    <td> Song Genre: </td>
    <td><b> <?php echo $Song_Genre; ?></b></td> 

  <tr>
    <td> Song Language: </td>
    <td><b> <?php echo $Song_Language?></b></td>

  <tr>
    <td> Released Date: </td>
    <td><b> <?php echo $Release_Date; ?></b></td>

  </table> 

<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "songsdb";
$conn = new mysqli($host,$user,$password,$db);

if ($conn->connect_error) {
  die ("DB ERROR..." . $conn->connect_error);
}
else
{
$DBQuery = "INSERT INTO SONGS (Song_Title, Song_Artist, Song_URL, Song_Genre, Song_Language, Release_Date, Owner_ID, Song_Status )
VALUES ('".$Song_Title."', '".$Song_Artist."', '".$Song_URL."', '".$Song_Genre."', '".$Song_Language."', '".$Release_Date."', '".$_SESSION["UserID"]."','pending')";

if ($conn->query($DBQuery) === TRUE) {
  echo "<p style='color:blue;'>Success insert NEW SONG</p>";
} else {
  echo "<p style='color:red;'>Fail to insert" . $conn->error. "</p>";
}
}
$conn->close();
?>
<br>
<p> Click <a href="newsongs_form.php">here</a> to enter NEW SONGS details. </p>
<p> Click <a href="viewSongs.php">here</a> to view ALL SONGS details.</p>

</body>
</html>

<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>
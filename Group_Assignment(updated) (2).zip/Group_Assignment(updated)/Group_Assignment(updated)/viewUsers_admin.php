<?php
session_start();
//check if session exists
if(isset($_SESSION["UserID"])) {
?>
<!DOCTYPE html>
<html>
<head>
<title> Special Songs Collection </title>

<style>
  body{
    background-image: url("Lagu3.webp");
  }

  table{
    background-color: white;
  }
  </style>
</head>

<body>
    <h2> User List </h2>

<?php
$host = "localhost";
$user = "root";
$password = "";
$db = "songsdb";
$conn = new mysqli($host,$user,$password,$db);

if ($conn->connect_error) {
    die ("Connection Failed..." . $conn->connect_error);
  }
  else
  {
    $queryView = "SELECT * FROM users WHERE UserType='user'";
    $resultQ = $conn->query($queryView);
?>

<table border="2">
  <tr>
    <th> USER ID</th>
    <th> User Type</th>
    <th> User Status </th>
   
  </tr>

<?php
if ($resultQ->num_rows > 0) {
    while ($row = $resultQ->fetch_assoc()){
?>
<tr>
    <td> <?php echo $row["UserID"]; ?> </td>
    <td> <?php echo $row["UserType"]; ?> </td>
    <td> <?php echo $row["UserStatus"]; ?> </td>
</tr>

<?php
    }
    } else {
        echo "<tr><td colspan='3'> NO data selected </td></tr>";
    }
}
?>
</table>

<?php
$conn->close();
?>

<br>
<p> Click <a href="menu.php">here</a> back to MENU page. </p>
<p> Click <a href="songs_statusView.php">here</a> Change songs status page. </p>
<p> Click <a href="Songs_adminManageView.php">here</a> Change user status page. </p>



</body>
</html>
<?php
}
else
{
echo "No session exists or session has expired. Please
log in again.<br>";
echo "<a href=login.html> Login </a>";
}
?>